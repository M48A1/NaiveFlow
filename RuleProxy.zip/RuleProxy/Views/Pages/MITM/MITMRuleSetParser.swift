//
//  MITMRuleSetParser.swift
//  RuleProxy
//
//  Created by NodePassProject on 5/8/26.
//

import Foundation
import JavaScriptCore

enum MITMRuleSetParser {
    private enum Section {
        case rule
        case parameter
        case ignored
    }

    static func parse(_ text: String) -> MITMRuleSet {
        var name = ""
        var suffixes: [String] = []
        var rules: [MITMRule] = []
        var parameters: [MITMParameter] = []
        var parameterNames: Set<String> = []
        var iconLight: Data?
        var iconDark: Data?
        var section: Section = .rule

        for raw in text.components(separatedBy: .newlines) {
            let line = raw.trimmingCharacters(in: .whitespaces)
            guard !line.isEmpty else { continue }
            if line.hasPrefix("#") || line.hasPrefix("//") { continue }

            if let next = parseSection(line) {
                section = next
                continue
            }

            if let header = parseHeader(line) {
                switch header.key {
                case "name":
                    name = header.value
                case "hostname":
                    suffixes = header.value
                        .split(separator: ",")
                        .map { $0.trimmingCharacters(in: .whitespaces) }
                        .filter { !$0.isEmpty }
                case "icon-light":
                    iconLight = Data(iconBase64: header.value)
                case "icon-dark":
                    iconDark = Data(iconBase64: header.value)
                default:
                    break
                }
                continue
            }

            switch section {
            case .rule:
                if let rule = parseRuleLine(line) { rules.append(rule) }
            case .parameter:
                guard parameters.count < MITMRuleSet.maxParameterCount else { continue }
                // Drop duplicate names: they'd collide as `RuleProxy.params` keys.
                if let parameter = parseParameterLine(line),
                   parameterNames.insert(parameter.name).inserted {
                    parameters.append(parameter)
                }
            case .ignored:
                break
            }
        }

        return MITMRuleSet(
            name: name,
            domainSuffixes: suffixes,
            rules: rules,
            parameters: parameters,
            iconLight: iconLight,
            iconDark: iconDark
        )
    }

    private static func parseSection(_ line: String) -> Section? {
        guard line.hasPrefix("["), line.hasSuffix("]"), line.count >= 2 else { return nil }
        let inner = line.dropFirst().dropLast()
            .trimmingCharacters(in: .whitespaces)
            .lowercased()
        switch inner {
        case "rule", "rules":
            return .rule
        case "parameter", "parameters", "param", "params":
            return .parameter
        default:
            return .ignored
        }
    }

    private static let recognizedHeaders: Set<String> = [
        "name",
        "hostname",
        "icon-light",
        "icon-dark",
    ]

    private static func parseHeader(_ line: String) -> (key: String, value: String)? {
        guard let equal = line.firstIndex(of: "=") else { return nil }
        let key = line[line.startIndex..<equal]
            .trimmingCharacters(in: .whitespaces)
            .lowercased()
        guard recognizedHeaders.contains(key) else { return nil }
        let value = String(line[line.index(after: equal)...])
            .trimmingCharacters(in: .whitespaces)
        return (key, value)
    }

    // MARK: - Rewrite sub-mode parsing

    private static func parseRewriteAction(subMode: String, fields: [String]) -> MITMRewriteAction? {
        switch subMode.trimmingCharacters(in: .whitespaces) {
        case "0":
            guard fields.count == 1, let url = validRewriteURL(fields[0]) else { return nil }
            return .transparent(url: url)
        case "1":
            guard fields.count == 1, let url = validRewriteURL(fields[0]) else { return nil }
            return .redirect302(url: url)
        case "2":
            guard fields.count <= 1 else { return nil }
            return .reject200Text(content: fields.first ?? "")
        case "3":
            guard fields.isEmpty else { return nil }
            return .reject200Gif
        case "4":
            guard fields.count <= 1 else { return nil }
            return .reject200Data(base64: fields.first ?? "")
        default:
            return nil
        }
    }

    private static func validRewriteURL(_ raw: String) -> String? {
        let trimmed = raw.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty,
              let urlComponents = URLComponents(string: trimmed),
              let host = urlComponents.host, !host.isEmpty else { return nil }
        return trimmed
    }

    // MARK: - Rule line parsing

    private static func parseRuleLine(_ trimmed: String) -> MITMRule? {
        let fields = splitCSV(trimmed)
        guard fields.count >= 2 else { return nil }
        guard let phaseCode = Int(fields[0]),
              let phase = phase(from: phaseCode) else { return nil }
        guard let operationCode = Int(fields[1]) else { return nil }
        let arguments = Array(fields.dropFirst(2))

        switch operationCode {
        case 0:
            guard arguments.count >= 2 else { return nil }
            let urlPattern = arguments[0]
            guard !urlPattern.isEmpty, isValidRegex(urlPattern) else { return nil }
            guard let action = parseRewriteAction(subMode: arguments[1], fields: Array(arguments.dropFirst(2))) else { return nil }
            return MITMRule(phase: .httpRequest, urlPattern: urlPattern, operation: .rewrite(action))

        case 1:
            guard arguments.count == 3 else { return nil }
            let urlPattern = arguments[0]
            let name = arguments[1]
            guard !urlPattern.isEmpty, isValidRegex(urlPattern), !name.isEmpty else { return nil }
            return MITMRule(phase: phase, urlPattern: urlPattern, operation: .headerAdd(name: name, value: arguments[2]))

        case 2:
            guard arguments.count == 2 else { return nil }
            let urlPattern = arguments[0]
            let name = arguments[1]
            guard !urlPattern.isEmpty, isValidRegex(urlPattern), !name.isEmpty else { return nil }
            return MITMRule(phase: phase, urlPattern: urlPattern, operation: .headerDelete(name: name))

        case 3:
            guard arguments.count == 3 else { return nil }
            let urlPattern = arguments[0]
            let name = arguments[1]
            guard !urlPattern.isEmpty, isValidRegex(urlPattern), !name.isEmpty else { return nil }
            return MITMRule(phase: phase, urlPattern: urlPattern, operation: .headerReplace(name: name, value: arguments[2]))

        case 4:
            guard arguments.count == 3 else { return nil }
            let urlPattern = arguments[0]
            let search = arguments[1]
            guard !urlPattern.isEmpty, isValidRegex(urlPattern),
                  !search.isEmpty, isValidRegex(search) else { return nil }
            return MITMRule(phase: phase, urlPattern: urlPattern, operation: .bodyReplace(search: search, replacement: arguments[2]))

        case 5:
            guard arguments.count >= 2 else { return nil }
            let urlPattern = arguments[0]
            guard !urlPattern.isEmpty, isValidRegex(urlPattern) else { return nil }
            guard let operation = parseJSONOperation(action: arguments[1], fields: Array(arguments.dropFirst(2))) else { return nil }
            return MITMRule(phase: phase, urlPattern: urlPattern, operation: .bodyJSON(operation))

        case 100:
            guard arguments.count == 2 else { return nil }
            let urlPattern = arguments[0]
            guard !urlPattern.isEmpty, isValidRegex(urlPattern) else { return nil }
            let scriptBase64 = arguments[1]
            guard !scriptBase64.isEmpty, isValidScriptBase64(scriptBase64) else { return nil }
            return MITMRule(
                phase: phase,
                urlPattern: urlPattern,
                operation: .script(scriptBase64: scriptBase64)
            )

        case 101:
            guard arguments.count == 2 else { return nil }
            let urlPattern = arguments[0]
            guard !urlPattern.isEmpty, isValidRegex(urlPattern) else { return nil }
            let scriptBase64 = arguments[1]
            guard !scriptBase64.isEmpty, isValidScriptBase64(scriptBase64) else { return nil }
            return MITMRule(
                phase: phase,
                urlPattern: urlPattern,
                operation: .streamScript(scriptBase64: scriptBase64)
            )

        default:
            return nil
        }
    }

    private static func parseJSONOperation(action rawAction: String, fields: [String]) -> MITMJSONOperation? {
        switch rawAction.trimmingCharacters(in: .whitespaces).lowercased() {
        case "add":
            guard fields.count == 2 else { return nil }
            return .add(path: fields[0], value: fields[1])
        case "replace":
            guard fields.count == 2 else { return nil }
            return .replace(path: fields[0], value: fields[1])
        case "delete":
            guard fields.count == 1 else { return nil }
            return .delete(path: fields[0])
        case "replace-recursive", "replacerecursive":
            guard fields.count == 2 else { return nil }
            return .replaceRecursive(key: fields[0], value: fields[1])
        case "delete-recursive", "deleterecursive":
            guard fields.count == 1 else { return nil }
            return .deleteRecursive(key: fields[0])
        case "remove-where-key-exists", "removewherekeyexists":
            guard fields.count == 2 else { return nil }
            return .removeWhereKeyExists(path: fields[0], key: fields[1])
        case "remove-where-field-in", "removewherefieldin":
            guard fields.count == 3 else { return nil }
            return .removeWhereFieldIn(path: fields[0], field: fields[1], values: fields[2])
        default:
            return nil
        }
    }

    // MARK: - Parameter line parsing

    private static func parseParameterLine(_ line: String) -> MITMParameter? {
        let fields = splitCSV(line)
        guard fields.count >= 6 else { return nil }
        guard let typeRaw = Int(fields[0]),
              let type = MITMParameter.InputType(rawValue: typeRaw) else { return nil }
        guard let dataRaw = Int(fields[1]),
              let dataType = MITMParameter.DataType(rawValue: dataRaw) else { return nil }
        let name = fields[2]
        guard isValidParameterName(name) else { return nil }
        let label = fields[3].isEmpty ? nil : fields[3]
        let description = fields[4].isEmpty ? nil : fields[4]
        let defaultValue = fields[5]
        let options = fields.count > 6 ? parseOptionList(fields[6]) : []

        switch type {
        case .input:
            return MITMParameter(
                type: .input,
                dataType: dataType,
                name: name,
                defaultValue: defaultValue,
                label: label,
                description: description
            )
        case .picker:
            guard !options.isEmpty else { return nil }
            var resolvedOptions = options
            let resolvedDefault: String
            if defaultValue.isEmpty {
                resolvedDefault = resolvedOptions[0]
            } else if options.contains(defaultValue) {
                resolvedDefault = defaultValue
            } else {
                resolvedOptions.insert(defaultValue, at: 0)
                resolvedDefault = defaultValue
            }
            return MITMParameter(
                type: .picker,
                dataType: dataType,
                name: name,
                defaultValue: resolvedDefault,
                options: resolvedOptions,
                label: label,
                description: description
            )
        }
    }

    private static func parseOptionList(_ field: String) -> [String] {
        var inner = field.trimmingCharacters(in: .whitespaces)
        if inner.hasPrefix("[") { inner.removeFirst() }
        if inner.hasSuffix("]") { inner.removeLast() }
        return inner
            .split(separator: ",")
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
    }

    private static func isValidParameterName(_ name: String) -> Bool {
        guard !name.isEmpty, name.utf8.count <= 128 else { return false }
        return name.allSatisfy { $0.isASCII && ($0.isLetter || $0.isNumber || $0 == "_") }
    }

    private static func phase(from raw: Int) -> MITMPhase? {
        switch raw {
        case 0: return .httpRequest
        case 1: return .httpResponse
        default: return nil
        }
    }

    private static func splitCSV(_ input: String) -> [String] {
        var fields: [String] = []
        var current = ""
        var i = input.startIndex
        while true {
            while i < input.endIndex, input[i] == " " || input[i] == "\t" {
                i = input.index(after: i)
            }
            if i < input.endIndex, input[i] == "\"" {
                i = input.index(after: i)
                while i < input.endIndex {
                    let character = input[i]
                    if character == "\"" {
                        let next = input.index(after: i)
                        if next < input.endIndex, input[next] == "\"" {
                            current.append("\"")
                            i = input.index(after: next)
                        } else {
                            i = next
                            break
                        }
                    } else {
                        current.append(character)
                        i = input.index(after: i)
                    }
                }
                while i < input.endIndex, input[i] == " " || input[i] == "\t" {
                    i = input.index(after: i)
                }
            } else {
                while i < input.endIndex, input[i] != "," {
                    current.append(input[i])
                    i = input.index(after: i)
                }
                current = current.trimmingCharacters(in: .whitespaces)
            }
            fields.append(current)
            current = ""
            if i >= input.endIndex { break }
            i = input.index(after: i)
        }
        return fields
    }

    private static func isValidRegex(_ pattern: String) -> Bool {
        (try? NSRegularExpression(pattern: pattern, options: [])) != nil
    }

    private static func isValidScriptBase64(_ base64: String) -> Bool {
        guard let raw = Data(base64Encoded: base64),
              let source = String(data: raw, encoding: .utf8)
        else { return false }
        let wrapped = "(function(){\n\(source)\nreturn process;\n})()"
        guard let context = JSContext() else { return false }
        return wrapped.withCString { cString in
            guard let scriptRef = JSStringCreateWithUTF8CString(cString) else {
                return false
            }
            defer { JSStringRelease(scriptRef) }
            return JSCheckScriptSyntax(
                context.jsGlobalContextRef,
                scriptRef,
                nil,
                0,
                nil
            )
        }
    }
}
