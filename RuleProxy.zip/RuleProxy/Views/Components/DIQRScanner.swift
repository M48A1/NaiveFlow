//
//  DIQRScanner.swift
//  RuleProxy
//
//  Created by NodePassProject on 2/16/26.
//

import SwiftUI
import AVFoundation

nonisolated private let logger = RuleProxyLogger(category: "DIQRScanner")

fileprivate struct CameraProperties {
    var session: AVCaptureSession = .init()
    var output: AVCaptureMetadataOutput = .init()
    var scannedCode: String?
    var permissionState: Permission?
    
    enum Permission: String {
        case idle = "Not Determined"
        case approved = "Access Granted"
        case denied = "Access Denied"
    }
    
    static func checkAndAskCameraPermission() async -> Permission? {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized: return Permission.approved
        case .notDetermined:
            if await AVCaptureDevice.requestAccess(for: .video) {
                return Permission.approved
            } else {
                return Permission.denied
            }
        case .denied, .restricted: return Permission.denied
        default: return nil
        }
    }
}

extension View {
    @ViewBuilder
    func qrScanner(isScanning: Binding<Bool>, onScan: @escaping (String) -> Void) -> some View {
        self
            .modifier(QRScannerViewModifier(isScanning: isScanning, onScan: onScan))
    }
}

fileprivate struct QRScannerViewModifier: ViewModifier {
    @Binding var isScanning: Bool
    var onScan: (String) -> Void
    @State private var showFullScreenCover: Bool = false
    func body(content: Content) -> some View {
        content
            .fullScreenCover(isPresented: $showFullScreenCover) {
                DIQRScannerView {
                    isScanning = false
                    Task { @MainActor in
                        showFullScreenCoverWithoutAnimation(false)
                    }
                } onScan: { code in
                    onScan(code)
                }
                .presentationBackground(.clear)
            }
            .onChange(of: isScanning) { oldValue, newValue in
                if newValue {
                    showFullScreenCoverWithoutAnimation(true)
                }
            }
    }
    
    private func showFullScreenCoverWithoutAnimation(_ status: Bool) {
        var transaction = Transaction()
        transaction.disablesAnimations = true
        withTransaction(transaction) {
            showFullScreenCover = status
        }
    }
}

fileprivate struct DIQRScannerView: View {
    var onClose: () -> ()
    var onScan: (String) -> Void
    @State private var isInitialized: Bool = false
    @State private var showContent: Bool = false
    @State private var isExpanding: Bool = false
    @State private var camera: CameraProperties = .init()
    @Environment(\.openURL) private var openURL
    var body: some View {
        GeometryReader {
            let size = $0.size
            let safeArea = $0.safeAreaInsets

            let haveDynamicIsland: Bool = safeArea.top >= 59
            let dynamicIslandWidth: CGFloat = 120
            let dynamicIslandHeight: CGFloat = 36
            let topOffset: CGFloat = haveDynamicIsland ? (11 + max((safeArea.top - 59), 0)) : (isExpanding ? safeArea.top : -50)
            
            let expandedWidth: CGFloat = min(size.width - 30, size.height - 30, 400)
            /// For making it square
            let expandedHeight: CGFloat = min(size.width - 30, size.height - 30, 400)
            
            ZStack(alignment: .top) {
                Rectangle()
                    .fill(.ultraThinMaterial)
                    .contentShape(.rect)
                    .opacity(isExpanding ? 1 : 0)
                    .onTapGesture {
                        toggle(false)
                    }

                if showContent {
                    RoundedRectangle(cornerRadius: 40)
                        .fill(.black)
                        .overlay {
                            GeometryReader {
                                let cameraSize = $0.size
                                
                                ScannerView(cameraSize)
                            }
                            .overlay(alignment: .bottom) {
                                Text("Scan your QR code")
                                    .font(.caption2)
                                    .foregroundStyle(.white.secondary)
                                    .lineLimit(1)
                                    .fixedSize()
                                    .offset(y: 25)
                            }
                            .padding(80)
                            .compositingGroup()
                            .blur(radius: isExpanding ? 0 : 15)
                            .opacity(isExpanding ? 1 : 0)
                            .geometryGroup()
                        }
                        .overlay {
                            PermissionDeniedView()
                        }
                        .frame(
                            width: isExpanding ? expandedWidth : dynamicIslandWidth,
                            height: isExpanding ? expandedHeight : dynamicIslandHeight
                        )
                        .offset(y: topOffset)
                        .background {
                            if isExpanding {
                                Rectangle()
                                    .fill(.clear)
                                    .onDisappear {
                                        showContent = false
                                    }
                            }
                        }
                        .transition(.identity)
                        .onDisappear {
                            onClose()
                        }
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
            .ignoresSafeArea()
            .task {
                guard !isInitialized else { return }
                isInitialized = true
                showContent = true
                try? await Task.sleep(for: .seconds(0.05))
                toggle(true)
                camera.permissionState = await CameraProperties.checkAndAskCameraPermission()
            }
            .onChange(of: camera.scannedCode) { oldValue, newValue in
                if let newValue {
                    onScan(newValue)
                    toggle(false)
                }
            }
        }
        .statusBarHidden()
    }

    @ViewBuilder
    private func ScannerView(_ size: CGSize) -> some View {
        let shape = RoundedRectangle(cornerRadius: 40)
        
        ZStack {
            if let permissionState = camera.permissionState {
                if permissionState == .approved {
                    CameraLayerView(size: size, camera: $camera)
                }
            }
            
            shape
                .stroke(.gray, lineWidth: 2)
        }
        .frame(width: size.width, height: size.height)
        .clipShape(shape)
    }

    @ViewBuilder
    private func PermissionDeniedView() -> some View {
        VStack(spacing: 4) {
            Image(systemName: "camera.viewfinder")
                .font(.system(size: 45))
                .foregroundStyle(.white)

            Text("Permission denied")
                .font(.caption)
                .foregroundStyle(.red)
            
            if let settingsURL = URL(string: UIApplication.openSettingsURLString) {
                Button("Go to Settings") {
                    openURL(settingsURL)
                }
                .font(.caption)
                .foregroundStyle(.white)
                .underline()
            }
        }
        .fixedSize()
        .compositingGroup()
        .opacity(camera.permissionState == .denied ? 1 : 0)
        .blur(radius: isExpanding ? 0 : 15)
        .opacity(isExpanding ? 1 : 0)
    }
    
    private func toggle(_ status: Bool) {
        withAnimation(.interpolatingSpring(duration: 0.35, bounce: 0, initialVelocity: 0)) {
            isExpanding = status
        }
        
        if !status {
            Task.detached(priority: .background) {
                await camera.session.stopRunning()
            }
        }
    }
}

fileprivate class CameraPreviewUIView: UIView {
    private let previewLayer: AVCaptureVideoPreviewLayer

    init(session: AVCaptureSession) {
        previewLayer = AVCaptureVideoPreviewLayer(session: session)
        previewLayer.videoGravity = .resizeAspectFill
        previewLayer.masksToBounds = true
        super.init(frame: .zero)
        layer.addSublayer(previewLayer)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError() }

    func updateSize(_ size: CGSize) {
        frame.size = size
        setNeedsLayout()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        previewLayer.frame = bounds
        if let connection = previewLayer.connection, connection.isVideoRotationAngleSupported(videoRotationAngle) {
            connection.videoRotationAngle = videoRotationAngle
        }
    }
    
    private var videoRotationAngle: CGFloat {
        switch window?.windowScene?.effectiveGeometry.interfaceOrientation {
        case .landscapeLeft: return 180
        case .landscapeRight: return 0
        case .portraitUpsideDown: return 270
        default: return 90
        }
    }
}

fileprivate struct CameraLayerView: UIViewRepresentable {
    var size: CGSize
    @Binding var camera: CameraProperties
    func makeUIView(context: Context) -> CameraPreviewUIView {
        let view = CameraPreviewUIView(session: camera.session)
        view.backgroundColor = .clear
        return view
    }

    func updateUIView(_ uiView: CameraPreviewUIView, context: Context) {
        uiView.updateSize(size)
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
    
    class Coordinator: NSObject, AVCaptureMetadataOutputObjectsDelegate {
        var parent: CameraLayerView
        init(parent: CameraLayerView) {
            self.parent = parent
            super.init()
            Task {
                setupCamera()
            }
        }
        
        func setupCamera() {
            do {
                let session = parent.camera.session
                let output = parent.camera.output
                
                guard !session.isRunning else { return }
                /// Virtual multi-camera device auto-switches to ultra-wide for macro when close.
                let discovery = AVCaptureDevice.DiscoverySession(deviceTypes: [.builtInTripleCamera, .builtInDualCamera, .builtInWideAngleCamera], mediaType: .video, position: .back)
                guard let device = discovery.devices.first else {
                    return
                }

                let input = try AVCaptureDeviceInput(device: device)
                guard session.canAddInput(input), session.canAddOutput(output) else {
                    return
                }

                session.beginConfiguration()
                session.addInput(input)
                session.addOutput(output)
                output.metadataObjectTypes = [.qr]
                output.setMetadataObjectsDelegate(self, queue: .main)
                session.commitConfiguration()

                /// Set zoom AFTER configuration, otherwise commitConfiguration resets it; engages the telephoto lens.
                try device.lockForConfiguration()
                let switchOverFactors = device.virtualDeviceSwitchOverVideoZoomFactors
                if let telephotoZoom = switchOverFactors.last?.doubleValue {
                    device.videoZoomFactor = min(telephotoZoom, device.activeFormat.videoMaxZoomFactor)
                } else {
                    device.videoZoomFactor = min(2.0, device.activeFormat.videoMaxZoomFactor)
                }
                device.unlockForConfiguration()
                Task.detached(priority: .background) {
                    session.startRunning()
                }
            } catch {
                logger.report("[QR] Camera configuration failed", error: error)
            }
        }
        
        func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
            if let object = metadataObjects.first as? AVMetadataMachineReadableCodeObject, let code = object.stringValue {
                guard parent.camera.scannedCode == nil else { return }
                parent.camera.scannedCode = code
                AudioServicesPlaySystemSound(SystemSoundID(kSystemSoundID_Vibrate))
            }
        }
    }
}
