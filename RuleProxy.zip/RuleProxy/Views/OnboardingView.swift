//
//  OnboardingView.swift
//  RuleProxy
//
//  Created by NodePassProject on 3/9/26.
//

import Foundation
import SwiftUI

struct OnboardingView: View {
    @Environment(Operations.self) private var operations
    @Environment(RoutingRuleSetStore.self) private var ruleSetStore
    @Binding var onboardingCompleted: Bool

    @State private var bypassCountryCode = AWCore.getBypassCountryCode()

    @State private var currentPage = 0
    @State private var isGoingForward = true
    @State private var adBlockEnabled = false

    var body: some View {
        VStack(spacing: 0) {
            VStack {
                switch currentPage {
                case 0: countryBypassPage
                default: adBlockPage
                }
            }
            .animation(.default, value: currentPage)
            
            bottomBar
                .padding(.horizontal, 24)
                .padding(.bottom, 16)
        }
        .background(
            BackgroundGradient()
                .ignoresSafeArea()
        )
        .onAppear {
            if let country = CountryBypassCatalog.shared.suggestedCountryCode() {
                bypassCountryCode = country
            }
        }
    }

    // MARK: - Bottom Bar

    private var bottomBar: some View {
        HStack {
            if currentPage > 0 {
                Button {
                    isGoingForward = false
                    currentPage -= 1
                } label: {
                    Text("Back")
                        .fontWeight(.medium)
                        .foregroundStyle(.primary)
                }
                .buttonStyle(.plain)
            }

            Spacer()

            Button {
                if currentPage < 1 {
                    isGoingForward = true
                    currentPage += 1
                } else {
                    finishOnboarding()
                }
            } label: {
                Text(currentPage < 1 ? "Next" : "Get Started")
                    .fontWeight(.semibold)
                    .padding(.horizontal, 24)
                    .padding(.vertical, 12)
                    .background(.white.opacity(0.8), in: Capsule())
            }
            .buttonStyle(.plain)
        }
        .padding(.top, 8)
    }

    // MARK: - Page 1: Country Bypass

    private var countryBypassPage: some View {
        VStack {
            VStack(spacing: 24) {
                Spacer(minLength: 40)

                Image(systemName: "globe.americas.fill")
                    .font(.system(size: 56))

                VStack(spacing: 8) {
                    Text("Country Bypass")
                        .font(.title.bold())
                    Text("Route traffic to your home country directly, bypassing the proxy for faster local access.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 32)
                }
                
                ScrollView {
                    VStack(spacing: 0) {
                        Button {
                            bypassCountryCode = ""
                        } label: {
                            HStack {
                                Text("Disable")
                                Spacer()
                                if bypassCountryCode == "" {
                                    Image(systemName: "checkmark")
                                        .fontWeight(.semibold)
                                        .foregroundStyle(Color.accentColor)
                                }
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        ForEach(CountryBypassCatalog.shared.supportedCountryCodes, id: \.self) { code in
                            Divider().opacity(0.3)
                            countryRow(code: code) {
                                bypassCountryCode = code
                            }
                        }
                    }
                    .background(.white.opacity(0.8), in: RoundedRectangle(cornerRadius: 24))
                    .padding(.horizontal, 24)
                }
            }
        }
    }

    @ViewBuilder
    private func countryRow(code: String, action: @escaping () -> Void) -> some View {
        let name = Locale.current.localizedString(forRegionCode: code) ?? code
        Button(action: action) {
            HStack {
                Text("\(flag(for: code)) \(name)")
                Spacer()
                if bypassCountryCode == code {
                    Image(systemName: "checkmark")
                        .fontWeight(.semibold)
                        .foregroundStyle(Color.accentColor)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    // MARK: - Page 2: AD Block

    private var adBlockPage: some View {
        VStack(spacing: 24) {
            Spacer()

            Image(systemName: "shield.checkered")
                .font(.system(size: 56))

            VStack(spacing: 8) {
                Text("Block Advertisements")
                    .font(.title.bold())
                Text("Block ads and trackers at the network level for a cleaner browsing experience.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 32)
            }

            Button {
                withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) {
                    adBlockEnabled.toggle()
                }
            } label: {
                HStack {
                    Image(systemName: adBlockEnabled ? "checkmark.shield.fill" : "shield.slash")
                        .font(.title2)
                        .foregroundStyle(adBlockEnabled ? .green : .secondary)
                        .contentTransition(.symbolEffect(.replace))
                    Text("Block Advertisements")
                        .font(.body.weight(.medium))
                    Spacer()
                    Toggle("", isOn: $adBlockEnabled)
                        .labelsHidden()
                }
                .padding(16)
                .background(.white.opacity(0.8), in: RoundedRectangle(cornerRadius: 24))
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 24)

            Spacer()
            Spacer()
        }
    }

    // MARK: - Actions

    private func finishOnboarding() {
        if DeviceCensorship.isChinaDevice {
            triggerNetworkPermission()
        }
        
        if adBlockEnabled {
            if let adBlock = ruleSetStore.adBlockRuleSet {
                operations.routingRuleSets.updateAssignment(adBlock, configurationId: "REJECT")
            }
        }
        
        operations.routingRuleSets.setBypassCountryCode(bypassCountryCode)

        AWCore.setOnboardingCompleted(true)

        withAnimation {
            onboardingCompleted = true
        }
    }

    // MARK: - Helpers

    private func flag(for countryCode: String) -> String {
        String(countryCode.unicodeScalars.compactMap {
            UnicodeScalar(127397 + $0.value)
        }.map(Character.init))
    }
    
    private func triggerNetworkPermission() {
        guard let url = URL(string: "https://captive.apple.com") else { return }
        Task { _ = try? await URLSession.shared.data(from: url) }
    }
}
