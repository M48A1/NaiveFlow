//
//  RuleProxyApp.swift
//  RuleProxy
//
//  Created by NodePassProject on 1/23/26.
//

import SwiftUI

@main
struct RuleProxyApp: App {
    @State private var container: AppContainer
    @State private var operations: Operations
    @State private var settings: AppSettings
    @State private var mitmCertificateController = MITMCertificateController()
    @State private var deepLinkManager = DeepLinkManager()

    init() {
        let container = AppContainer()
        container.start()
        let operations = Operations(container: container)

        let settings = AppSettings()
        settings.onTunnelBehaviorChange = { [weak tunnel = container.tunnel] in
            tunnel?.reconnect()
        }

        Task { await CloudSync.shared.start { keys in await operations.reload(keys) } }

        _container = State(initialValue: container)
        _operations = State(initialValue: operations)
        _settings = State(initialValue: settings)
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .dynamicTypeSize(...DynamicTypeSize.large)
                .environment(operations)
                .environment(container.appState)
                .environment(container.tunnel)
                .environment(container.selection)
                .environment(container.latency)
                .environment(container.stats)
                .environment(container.configurationStore)
                .environment(container.chainStore)
                .environment(container.groupStore)
                .environment(container.subscriptionStore)
                .environment(container.routingRuleSetStore)
                .environment(container.mitmRuleSetStore)
                .environment(container.moduleStore)
                .environment(container.certificateStore)
                .environment(settings)
                .environment(mitmCertificateController)
                .environment(deepLinkManager)
        }
    }
}
